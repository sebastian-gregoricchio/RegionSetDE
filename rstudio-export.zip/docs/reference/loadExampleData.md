# loadExampleData

Loads one of the example objects installed with RegionSetDE. The objects
cover the whole path from a collection of genomic regions to a fitted
model, and are the ones used throughout the vignette and the examples.

## Usage

``` r
loadExampleData(dataset = "counts", verbose = TRUE)
```

## Arguments

- dataset:

  String indicating which object to load, one among `"counts"`, `"fit"`,
  `"regions"`, `"exclusionRegions"`, `"sampleSheet"`, `"peakSheet"` and
  `"buildMetadata"`. The string `"blacklist"` is accepted as a synonym
  of `"exclusionRegions"`. Default: `"counts"`.

- verbose:

  Logical value to indicate whether the loading message must be printed.
  Default: `TRUE`.

## Value

The requested object. `"counts"` returns a `RegionSetDE.counts` object,
unnormalised and unfiltered, with the background bins already stored in
its metadata. `"fit"` returns a `RegionSetDE.fit` object ready for
[`testRegions`](https://sebastian-gregoricchio.github.io/RegionSetDE/reference/testRegions.md)
and
[`testRegionSets`](https://sebastian-gregoricchio.github.io/RegionSetDE/reference/testRegionSets.md).
`"regions"` returns a data.frame with one row per region and its set
membership, `"exclusionRegions"` a `GRanges`, `"sampleSheet"` a
data.frame describing every library of the source dataset, `"peakSheet"`
the sheet of the nine peak files and BAM files of the androgen receptor
example, read with
[`loadSampleSheet`](https://sebastian-gregoricchio.github.io/RegionSetDE/reference/loadSampleSheet.md)
so that the paths point at the installed files, and `"buildMetadata"` a
list with the parameters used to generate the others.

## Details

Two datasets are installed with the package, one for each end of the
workflow.

Everything but `"peakSheet"` comes from the liver ChIP-seq libraries of
the EURATRANS project, distributed by the `chromstaRData` package and
aligned to rn4. The contrast is H3K4me3 in the spontaneously
hypertensive (SHR) rat against the Brown Norway (BN) strain, two
biological replicates each, restricted to chromosome 12. It starts from
a counts object, which is where an analysis of fixed windows or of an
existing count matrix begins.

`"peakSheet"` points at the other one, which starts a step earlier, from
peak files and alignments. It is a slice of the androgen receptor
ChIP-seq of GSE284522: LNCaP cells treated with DMSO, or with the
synthetic androgen R1881 for four or twenty-four hours, three replicates
each, plus one input. The alignments are cut down to a window of
chromosome 19 and subsampled, so the counts are the real ones scaled by
a known fraction; the peaks are the calls of the full libraries filtered
to the same window.
`system.file("extdata", "lncapAR", "SOURCES.md", package = "RegionSetDE")`
says exactly what was done to them.

The regions are one kilobase windows split into four sets ordered by the
amount of H3K4me3 they are expected to carry: promoters overlapping a
CpG island, promoters without one, positions inside gene bodies away
from any transcription start site, and intergenic positions that serve
as the low-signal control. The sets are disjoint, and a window claimed
by an earlier set is never reused by a later one.

Only the counts are stored on disk. Asking for `"fit"` runs
[`normalizeCounts`](https://sebastian-gregoricchio.github.io/RegionSetDE/reference/normalizeCounts.md),
[`filterRegions`](https://sebastian-gregoricchio.github.io/RegionSetDE/reference/filterRegions.md)
and
[`fitRegions`](https://sebastian-gregoricchio.github.io/RegionSetDE/reference/fitRegions.md)
on them, with the parameters recorded in `"buildMetadata"`, and keeps
the result for the rest of the session. A fitted model carries the
internals of its engine, and those change between releases of `edgeR`
and `limma`, so a serialised fit would break as soon as the engine moved
underneath it.

rn4 has no curated blacklist, so `"exclusionRegions"` is assembled from
the UCSC assembly gap track and from bins carrying implausible coverage
in the input libraries. It is not an ENCODE-grade exclusion list and
should not be reused outside these examples.

The scripts that generated the stored objects and the peak files are
installed with the package, at
`system.file("scripts", package = "RegionSetDE")`.

## See also

[`loadRegions`](https://sebastian-gregoricchio.github.io/RegionSetDE/reference/loadRegions.md),
[`splitLoadRegions`](https://sebastian-gregoricchio.github.io/RegionSetDE/reference/splitLoadRegions.md),
[`applyBlacklist`](https://sebastian-gregoricchio.github.io/RegionSetDE/reference/applyBlacklist.md),
[`countReads`](https://sebastian-gregoricchio.github.io/RegionSetDE/reference/countReads.md),
[`countBackground`](https://sebastian-gregoricchio.github.io/RegionSetDE/reference/countBackground.md),
[`fitRegions`](https://sebastian-gregoricchio.github.io/RegionSetDE/reference/fitRegions.md)

## Author

Sebastian Gregoricchio

## Examples

``` r
counts <- loadExampleData("counts")
#> Loaded the 'counts' example object (RegionSetDE.counts).
counts
#> class: RegionSetDE.counts 
#> dim: 3224 4 
#> metadata(3): signal.type count.like background
#> assays(1): counts
#> rownames(3224): promoterNonCpG|region_00002 promoterNonCpG|region_00003
#>   ... promoterCpG|region_03797 promoterCpG|region_03798
#> rowData names(4): region.set region.id tile.id regionId
#> colnames(4): lv-H3K4me3-BN-female-bio1-tech1
#>   lv-H3K4me3-BN-male-bio2-tech1 lv-H3K4me3-SHR-male-bio2-tech1
#>   lv-H3K4me3-SHR-male-bio3-tech1
#> colData names(7): sample bam.file ... paired.end library.size

fit <- loadExampleData("fit", verbose = FALSE)
results <- testRegions(fit, contrast = c("condition", "SHR", "BN"), verbose = FALSE)
topRegions(results, n = 5, FDR = 1)
#>       region.set    region.id tile.id seqnames    start      end width
#> 1 promoterNonCpG region_02996      NA    chr12 36842295 36843294  1000
#> 2     intergenic region_03590      NA    chr12 44174500 44175499  1000
#> 3 promoterNonCpG region_00212      NA    chr12  2500829  2501828  1000
#> 4       geneBody region_02435      NA    chr12 29881730 29882729  1000
#> 5       geneBody region_02220      NA    chr12 27481625 27482624  1000
#>      log2FC average.signal average.signal.BN average.signal.SHR     stat
#> 1 -5.203835       5.159079          6.078432           2.651961 84.13617
#> 2 -2.887100       5.237329          5.930447           4.057310 43.04577
#> 3 -3.222630       4.816977          5.557234           3.451580 34.29977
#> 4 -2.778908       5.406565          6.079193           4.289880 36.15528
#> 5 -2.281658       5.277404          5.837722           4.471639 29.11255
#>   stat.distribution df1      df2      p.value          FDR diff.status
#> 1                 f   1 20.32506 1.148685e-08 2.176757e-05        down
#> 2                 f   1 19.05860 2.743053e-06 2.599042e-03        down
#> 3                 f   1 18.45056 1.370844e-05 6.573186e-03        down
#> 4                 f   1 17.03010 1.387480e-05 6.573186e-03        down
#> 5                 f   1 18.93934 3.347081e-05 1.268544e-02        down
#>       regionId
#> 1 region_02996
#> 2 region_03590
#> 3 region_00212
#> 4 region_02435
#> 5 region_02220
```
