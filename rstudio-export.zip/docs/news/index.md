# Changelog

## RegionSetDE 0.99.0

First version.

### Regions and counting

- [`loadRegions()`](https://sebastian-gregoricchio.github.io/RegionSetDE/reference/loadRegions.md)
  reads region sets from BED, narrowPeak, broadPeak or GRanges and keeps
  them as named sets of arbitrary width inside a `RegionSetDE` object.

- [`applyBlacklist()`](https://sebastian-gregoricchio.github.io/RegionSetDE/reference/applyBlacklist.md)
  and
  [`applyWhitelist()`](https://sebastian-gregoricchio.github.io/RegionSetDE/reference/applyWhitelist.md)
  restrict the regions, and record what they removed in the
  `filtering.log` slot. A list carrying an assembly different from the
  one of the regions is refused rather than overlapped, since rat chr1
  and human chr1 share a name and nothing else.

- [`loadBlacklist()`](https://sebastian-gregoricchio.github.io/RegionSetDE/reference/loadBlacklist.md)
  and
  [`loadGreenlist()`](https://sebastian-gregoricchio.github.io/RegionSetDE/reference/loadGreenlist.md)
  return the region lists shipped with the package as `GRanges`, ready
  for
  [`applyBlacklist()`](https://sebastian-gregoricchio.github.io/RegionSetDE/reference/applyBlacklist.md)
  or for the counting: the ENCODE blacklist version 2 for hg19, hg38,
  mm10, dm3, dm6, ce10 and ce11, the exclusion set of T2T-CHM13v2.0 from
  `excluderanges`, which ENCODE never covered, and the greenlists and
  high signal regions of the CUT&RUN greenlist paper for hg38 and mm39,
  one list per assay. The assembly is named in whatever way it is
  usually named, `"GRCh38"` or `"T2T"` for instance, and `source` picks
  between lists when a genome carries more than one. The files travel
  with the package, so nothing is downloaded and no hub has to be
  reachable, and
  [`availableRegionLists()`](https://sebastian-gregoricchio.github.io/RegionSetDE/reference/availableRegionLists.md)
  prints what is there with the source, the version and the size of each
  list.

- [`makeGreylist()`](https://sebastian-gregoricchio.github.io/RegionSetDE/reference/makeGreylist.md)
  builds a greylist from the input libraries, following GreyListChIP:
  windows of 1 kb overlapping by half, a negative binomial fitted to the
  counts of each input, and the windows above its 0.99 quantile merged
  when closer than 16 kb. The fit uses every window rather than
  bootstrap samples, so the result does not depend on the random seed.
  [`applyGreylist()`](https://sebastian-gregoricchio.github.io/RegionSetDE/reference/applyGreylist.md)
  removes the regions it covers, or trims them with
  `trimRegions = TRUE`, records the step as a greylist and leaves the
  stored blacklist alone.

- A headerless BED4 or BED5 file gets its fourth column named `name`,
  and its fifth `score`, so
  [`splitLoadRegions()`](https://sebastian-gregoricchio.github.io/RegionSetDE/reference/splitLoadRegions.md)
  finds its default `splitBy` column in it. They were left as `V4` and
  `V5` before, and only BED6 files could be split by name.

- [`loadSampleSheet()`](https://sebastian-gregoricchio.github.io/RegionSetDE/reference/loadSampleSheet.md)
  reads a table with one row per sample: the BAM or bigWig file, the
  peaks called on it and the input it was sequenced against, the last
  two optional and shareable between samples, plus any annotation
  column. A sheet holding peaks and no signal file is accepted, since it
  is enough to build a consensus, and says so. A DiffBind sample sheet
  is read as it is. Relative paths are resolved against the folder of
  the sheet, and missing or unindexed files are reported together before
  anything is counted.

- [`loadConsensusPeaks()`](https://sebastian-gregoricchio.github.io/RegionSetDE/reference/loadConsensusPeaks.md)
  passes `seqlevelsStyle` on to
  [`consensusRegions::runConsensus()`](https://rdrr.io/pkg/consensusRegions/man/runConsensus.html),
  which renames the chromosomes to UCSC on its own. Without it a
  consensus asked for in Ensembl style came back as `chr19` while the
  peaks it was built from stayed `19`, and every overlap between the two
  was empty: `peak.samples` counted zero everywhere, and an exclusion
  list was applied to nothing.
  [`.peakOccupancy()`](https://sebastian-gregoricchio.github.io/RegionSetDE/reference/dot-peakOccupancy.md)
  now refuses two sets that share no chromosome rather than returning
  zeros.

- [`loadConsensusPeaks()`](https://sebastian-gregoricchio.github.io/RegionSetDE/reference/loadConsensusPeaks.md)
  builds the regions from the peaks of the samples: a consensus within
  each group through `consensusRegions`, pooled into a total consensus
  that becomes the region set. The peaks overlapping `blacklist` and
  `greylist`, the ENCODE list and the one of
  [`makeGreylist()`](https://sebastian-gregoricchio.github.io/RegionSetDE/reference/makeGreylist.md)
  for instance, are removed before the consensus, so that an artefact
  cannot merge with a genuine peak. The two lists are given separately
  and recorded the way
  [`applyBlacklist()`](https://sebastian-gregoricchio.github.io/RegionSetDE/reference/applyBlacklist.md)
  and
  [`applyGreylist()`](https://sebastian-gregoricchio.github.io/RegionSetDE/reference/applyGreylist.md)
  record them: the blacklist in the `blacklist` slot, which follows the
  regions into the counts and the results, the size of the greylist in
  `parameters$greylist`, and the peaks each list removed from every
  sample in the `filtering.log`.
  [`consensusData()`](https://sebastian-gregoricchio.github.io/RegionSetDE/reference/consensusData.md)
  keeps both lists and the removed peaks, with their sample and the list
  that removed them, and counts them per sample in `n.blacklist` and
  `n.greylist`. A blacklist built for another assembly than
  `genomeAssembly` is refused, GRCh38 and hg38 counting as one. Regions
  of the user can split the consensus into sets (`regionMode = "split"`)
  or replace it (`"replace"`). Every region carries `peak.<group>`,
  `peak.groups` and `peak.samples`, which follow it into the counts and
  the results, and the consensus data are kept in the new `consensus`
  slot of `RegionSetDE`, read with
  [`consensusData()`](https://sebastian-gregoricchio.github.io/RegionSetDE/reference/consensusData.md).

- [`consensusGroupList()`](https://sebastian-gregoricchio.github.io/RegionSetDE/reference/consensusGroupList.md)
  returns the consensus of every group of
  [`loadConsensusPeaks()`](https://sebastian-gregoricchio.github.io/RegionSetDE/reference/loadConsensusPeaks.md)
  as a named list of `GRanges`, some groups only through `groups`, with
  the chromosomes renamed through `seqlevelsStyle`, ready for the
  functions of ChIPseeker that take several peak sets.
  `asGRangesList = TRUE` returns a `GRangesList` instead.

- [`plotPeakUpset()`](https://sebastian-gregoricchio.github.io/RegionSetDE/reference/plotPeakUpset.md)
  draws the occupancy of the regions as an UpSet plot through
  `ComplexHeatmap`, one set per group or one per sample, with the
  colours of the other plots of the package, and writes the sizes above
  the bars horizontally. The plot is built with
  [`ComplexHeatmap::Heatmap()`](https://rdrr.io/pkg/ComplexHeatmap/man/Heatmap.html)
  on a plain matrix rather than with `UpSet()`: on R-devel
  [`aperm()`](https://rdrr.io/r/base/aperm.html) keeps the class of its
  input, and `ComplexHeatmap` then recurses without end inside
  `comb_name()` until the node stack overflows.

- [`countReads()`](https://sebastian-gregoricchio.github.io/RegionSetDE/reference/countReads.md)
  and
  [`countBigwig()`](https://sebastian-gregoricchio.github.io/RegionSetDE/reference/countBigwig.md)
  count over the regions, either one row per region or one row per tile,
  and return a `RegionSetDE.counts` object. A tiled object is marked as
  tiled, so
  [`testRegions()`](https://sebastian-gregoricchio.github.io/RegionSetDE/reference/testRegions.md)
  recombines the tiles of a region instead of treating each of them as a
  region of its own.

- [`countReads()`](https://sebastian-gregoricchio.github.io/RegionSetDE/reference/countReads.md)
  and
  [`countBigwig()`](https://sebastian-gregoricchio.github.io/RegionSetDE/reference/countBigwig.md)
  take a `sampleSheet`, which brings the files, the sample names and the
  annotation in one go, and fall back on the sheet the consensus was
  built from when no file is given at all. Regions built by
  [`loadConsensusPeaks()`](https://sebastian-gregoricchio.github.io/RegionSetDE/reference/loadConsensusPeaks.md)
  are therefore counted, per region or per tile, without naming the
  libraries a second time, and the occupancy columns follow them into
  the counts, the tables and the results.

- [`countBigwig()`](https://sebastian-gregoricchio.github.io/RegionSetDE/reference/countBigwig.md)
  takes `countLike` and does not round. Rounding coverage to integers
  does not make it a fragment count, and the negative binomial and voom
  engines refuse an object built from bigWig files unless `countLike`
  was declared or `assumeCountLike` overrides it in
  [`fitRegions()`](https://sebastian-gregoricchio.github.io/RegionSetDE/reference/fitRegions.md).
  [`loadCounts()`](https://sebastian-gregoricchio.github.io/RegionSetDE/reference/loadCounts.md)
  takes the same argument, for external matrices holding coverage rather
  than counts.

- [`sampleInfo()`](https://sebastian-gregoricchio.github.io/RegionSetDE/reference/sampleInfo.md)
  returns the sample table of a counts object, a fit or a results object
  as a data.frame, the annotation of the sheet with the library sizes,
  the layouts and the scaling factors the package added to it; `columns`
  keeps the ones named. It is
  [`SummarizedExperiment::colData()`](https://rdrr.io/pkg/SummarizedExperiment/man/SummarizedExperiment-class.html)
  in a form `dplyr` takes directly.

- [`regionRanges()`](https://sebastian-gregoricchio.github.io/RegionSetDE/reference/regionRanges.md),
  [`filteringLog()`](https://sebastian-gregoricchio.github.io/RegionSetDE/reference/filteringLog.md),
  [`genomeAssembly()`](https://sebastian-gregoricchio.github.io/RegionSetDE/reference/genomeAssembly.md),
  [`countingLevel()`](https://sebastian-gregoricchio.github.io/RegionSetDE/reference/countingLevel.md)
  and
  [`dispersionInfo()`](https://sebastian-gregoricchio.github.io/RegionSetDE/reference/dispersionInfo.md)
  read the regions, the filtering record, the assembly, the counting
  level and the dispersion summary of the objects, so neither the
  examples nor the vignettes reach into the slots with `@` any more.

- [`libInfo()`](https://sebastian-gregoricchio.github.io/RegionSetDE/reference/libInfo.md)
  summarises the libraries of a counts object in one table: the records
  of every BAM file, read from its index, the fragments that went
  through the filters of the counting, the fragments in the regions and
  the fraction of reads in regions (FRiP). A region shared by several
  sets counts once.

- [`countBackground()`](https://sebastian-gregoricchio.github.io/RegionSetDE/reference/countBackground.md)
  counts genome-wide bins alongside the regions, for the normalisation
  and for the null estimates.

- [`countGreenlist()`](https://sebastian-gregoricchio.github.io/RegionSetDE/reference/countGreenlist.md)
  counts the libraries over the greenlist regions, with the read filters
  of
  [`countReads()`](https://sebastian-gregoricchio.github.io/RegionSetDE/reference/countReads.md),
  and keeps the result beside the counts for
  `normalizeCounts(method = "greenlist")`.

- `excludeChromosomes` is read in either naming style, so `"chrM"`
  reaches the mitochondrial genome of a BAM that calls it `MT`, in
  [`countReads()`](https://sebastian-gregoricchio.github.io/RegionSetDE/reference/countReads.md),
  [`countBackground()`](https://sebastian-gregoricchio.github.io/RegionSetDE/reference/countBackground.md)
  and
  [`makeGreylist()`](https://sebastian-gregoricchio.github.io/RegionSetDE/reference/makeGreylist.md).
  A name that still matches nothing raises a warning rather than a
  message only visible with `verbose = TRUE`: the chromosomes left out
  decide the library sizes, and the silence was paid for by the
  normalisation.

- The conversion of a UCSC name to the Ensembl style mapped `chrM` to
  `M` instead of `MT`, because the prefix was taken off the name before
  the substitution could see it. It only showed on assemblies that
  `GenomeInfoDb` does not carry, where the manual path is the one that
  runs.

- The counting finds a CSI index as well as a BAI, looking for
  `.bam.bai`, `.bai`, `.bam.csi` and `.csi` in that order and handing
  the path to Rsamtools, which finds only the first two on its own. A
  BAI cannot address a contig longer than 512 Mb at all, so an assembly
  with large chromosomes has no other option than `samtools index -c`.

- [`countReads()`](https://sebastian-gregoricchio.github.io/RegionSetDE/reference/countReads.md)
  and
  [`countBackground()`](https://sebastian-gregoricchio.github.io/RegionSetDE/reference/countBackground.md)
  rebuild each paired-end fragment from the first mate of the pair and
  its template length, and read the BAM files in pieces shared among the
  threads. `excludeChromosomes` keeps chromosomes such as chrM out of
  the library sizes and of the background bins, while
  `fullLibrarySize = FALSE` reads only the chromosomes carrying regions,
  which is faster but gives library sizes that are not meant for
  normalisation.

- [`countReads()`](https://sebastian-gregoricchio.github.io/RegionSetDE/reference/countReads.md)
  counts the inputs of the samples into an `input` assay, taken from the
  `input` column of the sample sheet or given through `inputFiles`: one
  row for every row of the counts, one column for every sample, `NA` for
  a sample without input. Each input file is read once, with the read
  filters of the samples, and a single-end input is extended to the mean
  fragment length of the samples it serves. `input.id` and
  `input.library.size` join the sample table, `countTable(input = TRUE)`
  returns the values, and `countInput = FALSE` skips them. Nothing
  subtracts them from the counts, which stay the reads of the samples as
  the count models need.

- [`countReads()`](https://sebastian-gregoricchio.github.io/RegionSetDE/reference/countReads.md)
  recentres the regions on their summit through `summits`, as
  [`DiffBind::dba.count()`](https://rdrr.io/pkg/DiffBind/man/dba.count.html)
  does: every region becomes a window of `2 * summits + 1` bp around the
  highest point of the fragment pileup, averaged over the samples with
  weights proportional to the height of their pileup over their depth.
  `summitSource = "peaks"` takes the summits the peak caller wrote in
  the narrowPeak files of a consensus instead, which needs no BAM file.
  `summits = 0` locates the summits and leaves the regions where they
  are. The summit of every region is kept in the `summit` column of the
  `rowData`, and the region identifiers still point at the regions the
  windows came from. Unlike `recentre = TRUE` of `consensusRegions`,
  which recentres within each group before the groups are pooled, this
  works on the pooled regions and gives them all the same width.

- The fragment length of single-end libraries can differ from sample to
  sample. `fragmentLength` in
  [`countReads()`](https://sebastian-gregoricchio.github.io/RegionSetDE/reference/countReads.md)
  takes one value per sample, the name of a column of the sample sheet
  holding them, for instance the fragment length computed by
  phantompeakqualtools, or `"auto"` to estimate it from the reads. The
  lengths are stored in the `fragment.length` column of the sample
  table, and
  [`countBackground()`](https://sebastian-gregoricchio.github.io/RegionSetDE/reference/countBackground.md)
  and
  [`countGreenlist()`](https://sebastian-gregoricchio.github.io/RegionSetDE/reference/countGreenlist.md)
  reuse them sample by sample.

- [`estimateFragmentLength()`](https://sebastian-gregoricchio.github.io/RegionSetDE/reference/estimateFragmentLength.md)
  estimates the fragment length of single-end libraries from the strand
  cross-correlation of their reads: for every forward read it counts the
  reverse reads at each distance, and takes the most frequent distance
  past the read length, where the mappability peak sits. It reads the
  regions of the analysis, or the three longest chromosomes, and returns
  the estimates, the profiles and a plot of them. For paired-end
  libraries it reports the median insert size.

- [`libInfo()`](https://sebastian-gregoricchio.github.io/RegionSetDE/reference/libInfo.md)
  reports the fragment length of every sample and, when the inputs were
  counted, the input of each sample with its library size, its fragments
  in the regions and its FRiP, which is what the regions would collect
  with no enrichment at all.

### Normalisation and filtering

- [`normalizeCounts()`](https://sebastian-gregoricchio.github.io/RegionSetDE/reference/normalizeCounts.md)
  estimates scaling factors from the background bins, from the regions
  themselves, or takes them from outside, for instance from a spike-in.
  `backgroundHoldout` keeps a fraction of the bins out of that
  estimation, so that the rows used to check the calibration sit outside
  the whole preprocessing chain.

- `method = "greenlist"` is the spike-in free reference of CUT&RUN and
  CUT&Tag. The regions whose background is reproducible between
  experiments are counted by
  [`countGreenlist()`](https://sebastian-gregoricchio.github.io/RegionSetDE/reference/countGreenlist.md),
  and the factors come out of them by median of ratios, which is the
  size factor the greenlist paper computed with DESeq2, or through TMM
  or the plain total. Counts collected outside the package go in through
  `greenlistCounts`.

- `method = "readsInRegions"` takes the depth of a sample to be what it
  put in the regions, the reads in peaks of DiffBind. What it assumes is
  that the fraction of the library sitting in the regions belongs to the
  protocol rather than to the biology, which a redistributed mark breaks
  in the direction that hides the effect, and the documentation says so
  next to the method.
  [`plotNormComparison()`](https://sebastian-gregoricchio.github.io/RegionSetDE/reference/plotNormComparison.md)
  puts both new methods beside the others.

- [`plotSetMA()`](https://sebastian-gregoricchio.github.io/RegionSetDE/reference/plotSetMA.md)
  and
  [`plotNormComparison()`](https://sebastian-gregoricchio.github.io/RegionSetDE/reference/plotNormComparison.md)
  show what a normalisation did before anything is fitted on it. What
  they answer is whether the conclusions are sensitive to the
  normalisation assumption. Whether a global shift is technical or
  biological is not separable from endogenous data alone, and neither
  plot decides it.

- [`filterRegions()`](https://sebastian-gregoricchio.github.io/RegionSetDE/reference/filterRegions.md)
  removes the rows that carry too little signal to say anything, on
  average abundance alone so that the choice is independent of the
  contrast tested afterwards. Width-adjusted by default, since a
  threshold in reads otherwise keeps every broad region and drops every
  narrow one.

- [`countGreenlist()`](https://sebastian-gregoricchio.github.io/RegionSetDE/reference/countGreenlist.md)
  checks the libraries against the conditions under which de Mello et
  al. built the greenlists. The greenlist regions overlapping the
  regions of the object are left out by default
  (`excludeCounted = TRUE`): the lists were kept 5 kb away from genes so
  that no target binds there, and a region of the study falling on one
  of them says the target does bind there in these cells. Libraries
  below the depth required to enter the construction of the list, 1.5
  million reads for human CUT&RUN, 1 million for mouse CUT&RUN and
  500,000 for human CUT&Tag, raise a warning, and so do libraries
  covering fewer than half as many greenlist regions as the median one.
  The sample table of the stored counts gains `regions.covered` and
  `library.fraction`, and
  [`normalizeCounts()`](https://sebastian-gregoricchio.github.io/RegionSetDE/reference/normalizeCounts.md)
  says how many regions with reads in every sample the median of ratios
  rests on. The paper sets no rule per group of samples.

### Sample selection

- [`selectSamples()`](https://sebastian-gregoricchio.github.io/RegionSetDE/reference/selectSamples.md)
  filters the samples with
  [`dplyr::filter`](https://dplyr.tidyverse.org/reference/filter.html)
  syntax on the `colData`, and
  [`splitSamples()`](https://sebastian-gregoricchio.github.io/RegionSetDE/reference/splitSamples.md)
  splits an object into one piece per mark or assay. Both drop the
  stored normalisation by default, since factors estimated across marks
  describe a library composition that no longer exists once the object
  is subset.
- [`selectSamples()`](https://sebastian-gregoricchio.github.io/RegionSetDE/reference/selectSamples.md)
  subsets the greenlist counts stored in the metadata, and the files,
  layouts and fragment lengths recorded by the counting, along with the
  samples.
  [`countBackground()`](https://sebastian-gregoricchio.github.io/RegionSetDE/reference/countBackground.md),
  [`countGreenlist()`](https://sebastian-gregoricchio.github.io/RegionSetDE/reference/countGreenlist.md)
  and
  [`libInfo()`](https://sebastian-gregoricchio.github.io/RegionSetDE/reference/libInfo.md)
  refused a selection before, since the files no longer matched the
  samples, and the greenlist factors were computed on every sample of
  the original object.

### Fitting and testing

- [`fitRegions()`](https://sebastian-gregoricchio.github.io/RegionSetDE/reference/fitRegions.md)
  fits one model per region with `edgeR`, `limma-voom`, `limma-trend`,
  [`variancePartition::dream`](http://DiseaseNeurogenomics.github.io/variancePartition/reference/dream-method.md)
  or `DESeq2`, reading the normalisation out of the object as offsets
  rather than recomputing it. The `"limma"` engine runs limma-trend on
  the log2 signal, for values that are not counts.

- [`testRegions()`](https://sebastian-gregoricchio.github.io/RegionSetDE/reference/testRegions.md)
  tests a contrast, or a named list of them, and combines tiled regions
  back to one row per region: `combineMethod = "simes"` through
  [`csaw::combineTests()`](https://rdrr.io/pkg/csaw/man/combineTests.html),
  which asks whether any part of the region changed, and `"holm-min"`
  through
  [`csaw::minimalTests()`](https://rdrr.io/pkg/csaw/man/minimalTests.html),
  which asks several tiles to change together. Every tiled test used to
  fail, because `method` was handed to
  [`csaw::combineTests()`](https://rdrr.io/pkg/csaw/man/combineTests.html),
  which has no such argument in any release; csaw has one function per
  procedure instead. `"wilcoxon"` and `"stouffer"`, which had no csaw
  function behind them, are no longer accepted.

- The tiles counted as moving up and down in a combined region,
  `n.tiles.up` and `n.tiles.down`, were zero in every row. The
  `fc.threshold` of csaw is a false discovery rate within the region,
  not a fold change, and it was given the fold change threshold of the
  test, zero by default. It now takes 0.05, the value csaw uses.

- The results table carries the average signal of every level of the
  column the contrast compares, `average.signal.<level>`, next to the
  one over all the samples. Each is the same quantity as
  `average.signal` computed on that level alone, so the columns read
  side by side:
  [`edgeR::aveLogCPM`](https://rdrr.io/pkg/edgeR/man/aveLogCPM.html) for
  edgeR, the mean of the log2 values of the linear model for voom, limma
  and dream, `log2(baseMean + 1)` for DESeq2. `signalBy` averages over
  the levels of another column instead, and `signalBy = FALSE` leaves
  them out. Every contrast of a list gets the same columns, in the order
  of the levels in the sample table, so the stacked table lines up.

- The results table says which distribution `stat` follows under the
  null and with how many degrees of freedom, in `stat.distribution`,
  `df1` and `df2`: an F with the coefficients tested over the residual
  plus prior degrees of freedom for the quasi-likelihood test of edgeR,
  a chi-squared for its likelihood ratio, a t with the total degrees of
  freedom for voom, limma and dream, a standard normal for DESeq2.
  Handed back to the distribution, the three give the p-value of the
  engine, which the tests check for every engine. The threshold tests
  run with `lfcThreshold > 0` have no such distribution and say `NA`.

- [`contrastInfo()`](https://sebastian-gregoricchio.github.io/RegionSetDE/reference/contrastInfo.md)
  describes the contrasts of a results object, one row per contrast: the
  engine, the column and the two groups compared, the number of samples
  in each, the distribution of the statistic and its degrees of freedom.
  With the `stat` column it is what a power or sample size analysis
  needs, with power4peaks for instance. The group sizes are also kept in
  the `n.samples` element of the `contrast.groups` slot.

- [`pairwiseContrasts()`](https://sebastian-gregoricchio.github.io/RegionSetDE/reference/pairwiseContrasts.md)
  writes out the contrasts between the levels of a column, every pair or
  every level against a `reference`, as the named list
  [`testRegions()`](https://sebastian-gregoricchio.github.io/RegionSetDE/reference/testRegions.md)
  takes. The order of the levels sets the sign of the fold changes, and
  is read from the data rather than sorted.

- [`resultsTable()`](https://sebastian-gregoricchio.github.io/RegionSetDE/reference/resultsTable.md)
  on several contrasts labels the stacked rows with the name each
  contrast was given, the string
  [`topRegions()`](https://sebastian-gregoricchio.github.io/RegionSetDE/reference/topRegions.md),
  [`plotVolcano()`](https://sebastian-gregoricchio.github.io/RegionSetDE/reference/plotVolcano.md)
  and the other functions take through `contrast`, instead of its
  description, so that the table is filtered with the same string. The
  description follows in `contrast.description`.
  [`tileTable()`](https://sebastian-gregoricchio.github.io/RegionSetDE/reference/tileTable.md)
  does the same.

- [`updateThresholds()`](https://sebastian-gregoricchio.github.io/RegionSetDE/reference/updateThresholds.md)
  labels the regions of a result again with other `FDR` and `log2FC`
  cut-offs without testing again, on one contrast, on every contrast of
  a list or on the ones named in `contrast`. The thresholds stored in
  the object and the parameters recorded for the test are replaced, the
  previous ones kept in `parameters$updateThresholds`, so the tables,
  the plots and
  [`exportResults()`](https://sebastian-gregoricchio.github.io/RegionSetDE/reference/exportResults.md)
  follow the new cut-offs. On the results of the region sets it moves
  the `FDR` cut-off alone.

- Contrasts can be given as a coefficient name, an expression over the
  design columns, a numeric vector, or as
  `c("column", "groupA", "groupB")`, which works whatever the reference
  level is.

- [`peakOccupancyTable()`](https://sebastian-gregoricchio.github.io/RegionSetDE/reference/peakOccupancyTable.md)
  crosses the consensus a region came from with what the test said about
  it: how many of the regions called in both groups changed, how many of
  the group-specific ones did, and in which direction, or the same
  counts against the number of samples that carried a peak. It reads the
  `peak.*` columns, which travel from
  [`loadConsensusPeaks()`](https://sebastian-gregoricchio.github.io/RegionSetDE/reference/loadConsensusPeaks.md)
  through the counts and into the results on their own. What it is not
  is a test of occupancy, since whether a peak is called depends on the
  depth of the library and on the threshold of the caller, and the
  documentation says so where the table is printed.

- `RegionSetDE.results` records in `contrast.groups` the column and the
  two levels a contrast compares, as `RegionSetDE.setResults` already
  did. A contrast written as a coefficient name, an expression or a
  vector is assigned to the design variable it belongs to, never to a
  column naming each sample on its own, such as the sample names.

- A contrast that cannot be read no longer comes back with a suggestion
  about a reference level called `NA`: the hint is only given when a
  level of the design was written in the contrast.

- The documentation of
  [`fitRegions()`](https://sebastian-gregoricchio.github.io/RegionSetDE/reference/fitRegions.md)
  said the DESeq2 engine was there for its shrunken fold changes. It
  runs the Wald test with `betaPrior = FALSE` and never calls
  [`DESeq2::lfcShrink()`](https://rdrr.io/pkg/DESeq2/man/lfcShrink.html),
  so its fold changes are unshrunken like those of the other engines.
  The text now says so, and points to
  [`asDESeqDataSet()`](https://sebastian-gregoricchio.github.io/RegionSetDE/reference/asDESeqDataSet.md)
  for shrinking them.

### Region sets

- [`testRegionSets()`](https://sebastian-gregoricchio.github.io/RegionSetDE/reference/testRegionSets.md)
  asks whether a set responds as a whole, competitively through
  [`limma::cameraPR`](https://rdrr.io/pkg/limma/man/camera.html) and
  self-contained through
  [`limma::fry`](https://rdrr.io/pkg/limma/man/roast.html), with the
  variance inflated for the correlation between regions so that a large
  set does not come out certain by virtue of being large. The four
  combinations of the two outcomes are documented as evidence rather
  than as mechanism: failing to reject a self-contained null is not
  evidence that the absolute change is zero, unequal power between the
  two tests produces the same pattern, and a centring normalisation
  removes a genuinely global shift before `fry` ever sees the data.
- `effectMethod` decides what the confidence interval describes. With
  the default `"sample"` it is built from one set score per library, the
  mean signal over the set minus the mean signal over its comparison,
  run through the design of the experiment, so the replication behind it
  is the biological samples. `sample.delta.log2FC`, its standard error,
  degrees of freedom, p-value and adjusted p-value are reported
  alongside. `heterogeneity.CI.lower` and `heterogeneity.CI.upper`
  report the other quantity, how far the effect varies between the loci
  of a set, conditional on the libraries at hand.
- [`testSetContrast()`](https://sebastian-gregoricchio.github.io/RegionSetDE/reference/testSetContrast.md)
  asks whether a contrast affects one set differently from another,
  which is where a redistribution claim belongs.
- `tileHandling` collapses the tiles of a region into one row before the
  set is assembled. Without it a 40 kb region counted at 1 kb weighs
  forty times a 1 kb one, which makes the set effect an average over
  base pairs rather than over regions.
- `overlapPolicy` handles sets covering the same chromatin, found
  through
  [`IRanges::findOverlaps`](https://rdrr.io/pkg/IRanges/man/findOverlaps-methods.html)
  rather than through region identifiers, since two sets can cover the
  same chromatin without sharing an identifier and the shared reads pull
  the difference between them towards zero. `n.comparison.overlapping`
  reports how many comparison rows overlap.
- [`makeSetUniverse()`](https://sebastian-gregoricchio.github.io/RegionSetDE/reference/makeSetUniverse.md)
  builds the comparison universe, matched on width and abundance;
  [`fitRegions()`](https://sebastian-gregoricchio.github.io/RegionSetDE/reference/fitRegions.md)
  builds one automatically and keeps it in the fit. `universeSets` names
  the sets the comparison rows are drawn from, and
  `RegionSetDE.universe` records them in `comparison.sets` and prints
  them, since a competitive p-value is relative to the sets that happen
  to be loaded.

### Region set scores

- [`scoreRegionSets()`](https://sebastian-gregoricchio.github.io/RegionSetDE/reference/scoreRegionSets.md)
  compares region sets to each other in an experiment holding a single
  condition, where there is no contrast for
  [`testSetContrast()`](https://sebastian-gregoricchio.github.io/RegionSetDE/reference/testSetContrast.md)
  to run on. It computes one score per set per library, the summarised
  signal over the set divided by a reference measured in the same
  library, and compares the sets library by library.
- The replication is the libraries. The regions of a set collapse to one
  number per library rather than being tested across, so the interval
  rests on the biological samples and the p-value is not the vanishing
  one a per-region test over the same data returns.
- The score is a ratio taken inside one library, so the sequencing depth
  and the scaling factors cancel before it exists. With
  `reference = "background"` the regions are read from the raw `counts`
  assay, since the bins hold raw counts, and the normalisation never
  enters. The reference cancels a second time in the difference between
  two sets, which therefore depends on neither.
- What the comparison does not separate is the factor from the
  composition of the sets. Width, mappability, GC content and
  accessibility produce coverage in a library where nothing is bound,
  reproducibly across replicates. `perBasepair` removes the width term,
  and the documentation states plainly that the rest remain, so that the
  step from more signal to more factor is made as an argument rather
  than read off the output.
- `RegionSetDE.setScores` holds the per-library scores, the comparisons
  and the `colData` of the counts object. `show` prints the sets, the
  libraries, the reference and the comparisons;
  [`resultsTable()`](https://sebastian-gregoricchio.github.io/RegionSetDE/reference/resultsTable.md)
  returns the comparisons,
  [`scoreTable()`](https://sebastian-gregoricchio.github.io/RegionSetDE/reference/scoreTable.md)
  the scores behind them, and
  [`regionSetNames()`](https://sebastian-gregoricchio.github.io/RegionSetDE/reference/regionSetNames.md)
  works on the object.

### Designs without replicates

- [`estimateNullDispersion()`](https://sebastian-gregoricchio.github.io/RegionSetDE/reference/estimateNullDispersion.md)
  reads the between-sample variation off rows assumed not to respond, so
  that a design with one sample per condition has a dispersion to be
  tested against.
  [`fitRegions()`](https://sebastian-gregoricchio.github.io/RegionSetDE/reference/fitRegions.md)
  calls it on its own when the design leaves no residual. What it
  measures is how two libraries differ over those rows, which is not the
  biological variability that was never sampled, and the documentation
  says so.
- The returned list carries `holdout.type`, distinguishing rows held out
  of the dispersion alone from rows held out of both the dispersion and
  the normalisation.
- [`checkNullCalibration()`](https://sebastian-gregoricchio.github.io/RegionSetDE/reference/checkNullCalibration.md)
  runs the same contrast on rows that should not respond and reports how
  many come out significant anyway, broken down by abundance, with a
  suggested dispersion when the current one is off.

### Plots

- [`plotResultsMA()`](https://sebastian-gregoricchio.github.io/RegionSetDE/reference/plotResultsMA.md)
  draws the fold change cut-off of the labels as two dashed horizontal
  lines, the way
  [`plotVolcano()`](https://sebastian-gregoricchio.github.io/RegionSetDE/reference/plotVolcano.md)
  draws it as two vertical ones, and names its x axis after what the
  engine reports: log2 counts per million, or the log2 of the mean
  normalised count for DESeq2.

- Per region:
  [`plotVolcano()`](https://sebastian-gregoricchio.github.io/RegionSetDE/reference/plotVolcano.md),
  [`plotResultsMA()`](https://sebastian-gregoricchio.github.io/RegionSetDE/reference/plotResultsMA.md),
  [`plotRegion()`](https://sebastian-gregoricchio.github.io/RegionSetDE/reference/plotRegion.md),
  [`plotTopHeatmap()`](https://sebastian-gregoricchio.github.io/RegionSetDE/reference/plotTopHeatmap.md).

- [`plotPeakOccupancy()`](https://sebastian-gregoricchio.github.io/RegionSetDE/reference/plotPeakOccupancy.md)
  draws the table of
  [`peakOccupancyTable()`](https://sebastian-gregoricchio.github.io/RegionSetDE/reference/peakOccupancyTable.md)
  as stacked bars, one per occupancy class and split by direction, with
  `proportion = TRUE` for the composition of each class when the shared
  regions outnumber the specific ones.

- [`plotRegion()`](https://sebastian-gregoricchio.github.io/RegionSetDE/reference/plotRegion.md)
  draws brackets between the groups of `groupBy` through `pairwiseTest`.
  With `"model"` each bracket carries the fold change and the FDR of a
  fitted contrast comparing two of those groups. `"t.test"` and
  `"wilcox.test"` test the plotted values instead, paired through a
  `colData` column with `pairBy`, and `pAdjustMethod` corrects across
  the brackets of the plot. The caption names the test, the function
  warns when it runs on raw counts, and a message says when the groups
  are too small for the exact Wilcoxon test to reach 0.05.

- Per set:
  [`plotSetEffect()`](https://sebastian-gregoricchio.github.io/RegionSetDE/reference/plotSetEffect.md),
  [`plotSetDistribution()`](https://sebastian-gregoricchio.github.io/RegionSetDE/reference/plotSetDistribution.md),
  [`plotSetSignal()`](https://sebastian-gregoricchio.github.io/RegionSetDE/reference/plotSetSignal.md),
  [`plotUniverseMatching()`](https://sebastian-gregoricchio.github.io/RegionSetDE/reference/plotUniverseMatching.md).
  [`plotSetSignal()`](https://sebastian-gregoricchio.github.io/RegionSetDE/reference/plotSetSignal.md)
  also draws a `RegionSetDE.setScores` object, one point per library per
  set with the points of a library joined across the sets, since the
  comparison behind the bracket is paired.

- Samples:
  [`plotRegionPCA()`](https://sebastian-gregoricchio.github.io/RegionSetDE/reference/plotRegionPCA.md)
  and
  [`plotSampleCorrelation()`](https://sebastian-gregoricchio.github.io/RegionSetDE/reference/plotSampleCorrelation.md),
  both working on the normalised values by default, with
  `useOffsets = FALSE` for the library sizes alone and `compareOffsets`
  drawing the two side by side, so that a grouping caused by the scaling
  factors can be told apart from one in the data. A correlation does not
  move when a library is scaled by a single factor, and the
  documentation says where the comparison is worth making.

- [`plotSampleCorrelation()`](https://sebastian-gregoricchio.github.io/RegionSetDE/reference/plotSampleCorrelation.md)
  draws the heatmap through `ComplexHeatmap`: any column of the sample
  table can be added to the annotation bars with `annotationColumns`,
  with the colours of the package or the ones given through
  `annotationColours`, the samples are clustered on one minus the
  correlation, and the order of the first panel is reused by the others
  so that a comparison shows the values changing rather than the samples
  moving.

- [`computeSamplePCA()`](https://sebastian-gregoricchio.github.io/RegionSetDE/reference/computeSamplePCA.md)
  and
  [`computeSampleCorrelation()`](https://sebastian-gregoricchio.github.io/RegionSetDE/reference/computeSampleCorrelation.md)
  return the numbers behind the two figures, the coordinates, the
  variance explained and the loadings on one side, the correlation
  matrix and the sample table on the other, and both plotting functions
  take that output back as it is.

- [`plotSetDistribution()`](https://sebastian-gregoricchio.github.io/RegionSetDE/reference/plotSetDistribution.md)
  stretches the y axis to hold the effect size and the FDR written above
  each set, whose first line was cut by the panel when it sat above the
  highest fold change.

- [`computeProfiles()`](https://sebastian-gregoricchio.github.io/RegionSetDE/reference/computeProfiles.md)
  and
  [`plotProfile()`](https://sebastian-gregoricchio.github.io/RegionSetDE/reference/plotProfile.md)
  draw the signal around the centre of the regions, by default the
  regions going up and those going down in a contrast, the counterpart
  of
  [`DiffBind::dba.plotProfile()`](https://rdrr.io/pkg/DiffBind/man/dba.plotProfile.html).
  The signal is read from the BAM files with the filters of the counting
  and scaled by the normalisation of the object, or from bigWig files as
  they are. The `"heatmap"` style draws one heatmap per sample or group,
  with the mean profiles on top, the same row order in every panel and a
  shared colour scale; `"lines"` draws the mean profiles with their
  standard error. The regions are aligned on their summit when
  [`countReads()`](https://sebastian-gregoricchio.github.io/RegionSetDE/reference/countReads.md)
  located one, and the regions on the minus strand are read from right
  to left.

- [`computeSamplePCA()`](https://sebastian-gregoricchio.github.io/RegionSetDE/reference/computeSamplePCA.md),
  [`plotRegionPCA()`](https://sebastian-gregoricchio.github.io/RegionSetDE/reference/plotRegionPCA.md),
  [`computeSampleCorrelation()`](https://sebastian-gregoricchio.github.io/RegionSetDE/reference/computeSampleCorrelation.md),
  [`plotSampleCorrelation()`](https://sebastian-gregoricchio.github.io/RegionSetDE/reference/plotSampleCorrelation.md)
  and
  [`computeProfiles()`](https://sebastian-gregoricchio.github.io/RegionSetDE/reference/computeProfiles.md)
  take `samples`, by name, position or logical vector, to draw some of
  the libraries only. The normalisation of the whole analysis is kept,
  since the factors are one per sample, and `useOffsets = FALSE` gives
  the library sizes alone. The Jaccard index takes it too.

- [`computeProfiles()`](https://sebastian-gregoricchio.github.io/RegionSetDE/reference/computeProfiles.md)
  and
  [`plotProfile()`](https://sebastian-gregoricchio.github.io/RegionSetDE/reference/plotProfile.md)
  take `regions`, any `GRanges`, list of them or region set, besides the
  differential regions of a result and the sets of a counts object, and
  `blacklist` and `whitelist`: the first leaves out the rows whose drawn
  window touches the list, `TRUE` taking the blacklist stored in the
  object, the second keeps the regions overlapping it. `maxRegions` is
  applied after both, so the rows filtered out are replaced by the next
  ones.

- [`computeSampleCorrelation()`](https://sebastian-gregoricchio.github.io/RegionSetDE/reference/computeSampleCorrelation.md)
  and
  [`plotSampleCorrelation()`](https://sebastian-gregoricchio.github.io/RegionSetDE/reference/plotSampleCorrelation.md)
  take `method = "jaccard"`, which compares the samples on their peak
  calls rather than on their signal, as the Jaccard index of their peak
  sets, and clusters them on the Jaccard distance.
  `jaccardLevel = "region"` counts the places of the union of the peaks
  occupied by both samples, `"basepair"` the bases covered by both, as
  `bedtools jaccard` does. It works on the object returned by
  [`loadConsensusPeaks()`](https://sebastian-gregoricchio.github.io/RegionSetDE/reference/loadConsensusPeaks.md),
  whose sample sheet annotates the heatmap, or on a list of peak sets.

### Example data

- `loadExampleData("peakSheet")` returns the sheet of the androgen
  receptor example, nine `.narrowPeak` files with the alignments they
  were called from: AR ChIP-seq in LNCaP cells treated with DMSO or with
  R1881 for four or twenty-four hours, three replicates each plus an
  input, from GSE284522 (Eickhoff *et al.*, *Communications Biology*
  2025). The alignments are a window of chromosome 19 subsampled to 12 %
  of the read pairs, with the sequences, the qualities, the tags and the
  read names removed, which leaves the counts equal to the real ones
  scaled by a known factor and every ratio between samples intact; the
  peaks are the calls of the complete libraries filtered to the same
  window. `inst/extdata/lncapAR/SOURCES.md` records the provenance and
  `inst/scripts/make-example-bams.sh` the commands.
- The synthetic peak files derived from the EURATRANS counts are gone,
  together with `inst/scripts/make-example-peaks.R`. The androgen
  receptor data covers the peak-based workflow with real calls, and a
  ligand that recruits its receptor to chromatin gives the normalisation
  section something to be wrong about.

### Export

- [`asDGEList()`](https://sebastian-gregoricchio.github.io/RegionSetDE/reference/asDGEList.md),
  `as(x, "DGEList")` and
  [`asDESeqDataSet()`](https://sebastian-gregoricchio.github.io/RegionSetDE/reference/asDESeqDataSet.md)
  hand the counts to `edgeR` or `DESeq2` with the offsets attached the
  right way round.
- [`exportResults()`](https://sebastian-gregoricchio.github.io/RegionSetDE/reference/exportResults.md)
  writes the table, a BED coloured by direction, and every parameter the
  analysis was run with.
- [`countTable()`](https://sebastian-gregoricchio.github.io/RegionSetDE/reference/countTable.md)
  returns the values of a counts, fit or results object as a table, raw
  or normalised, with the coordinates and the annotation of each row.
  `format = "long"` repeats every row once per sample and attaches the
  `colData`, the shape `ggplot2` expects, and `format = "matrix"`
  returns a plain matrix. On a tiled object `level = "region"` combines
  the tiles back into their region, summing the reads and following
  `summaryFunction` for bigWig signal. A fragment crossing the border
  between two tiles is counted in both, so summed tiles come out higher
  than the same region counted whole, and a message says so.
